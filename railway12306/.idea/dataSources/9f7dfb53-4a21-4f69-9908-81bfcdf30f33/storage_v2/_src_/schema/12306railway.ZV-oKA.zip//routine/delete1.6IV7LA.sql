create
    definer = root@localhost procedure delete1(IN a varchar(100))
begin
insert into deleted 
select * from ticketlist where DINGDANHAO =a ;
delete from ticketlist where DINGDANHAO = a;
end;

